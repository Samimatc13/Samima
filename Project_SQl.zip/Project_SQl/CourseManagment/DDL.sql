create database coursedb
go
ALTER DATABASE coursedb
SET COMPATIBILITY_LEVEL =  130
go
use coursedb
go
create table techsubjects
(
	subjectid int identity primary key,
	technology nvarchar(50) not null
)
go
create table instructors
(
	instructorid int identity primary key,
	istructorname nvarchar(50) not null,
	email nvarchar(50) not null,
	phone nvarchar(25) not null
)
go
create table courses
(
	courseid int identity primary key,
	title nvarchar(150) not null,
	totalclass int not null,
	weeklyclass int not null,
	classduration int not null,
	fee money not null,
	instructorid int not null references instructors (instructorid)
)
go
create table instructorsubjects
(
	instructorid int not null references instructors (instructorid),
	subjectid int not null references techsubjects (subjectid),
	primary key (instructorid,subjectid)
)
go
create table [batches]
(
	batchid int identity primary key,
	startdate date not null,
	courseid int not null references courses (courseid)
)
go
create table students
(
	studentid int identity primary key,
	studentname nvarchar(30) not null,
	phone nvarchar(25) not null,
	batchid int not null references [batches] (batchid)
)
go
--procedure to insert instructor
create procedure spInsertInstructor @istructorname nvarchar(50),
	@email nvarchar(50),
	@phone nvarchar(25),
	@subjecids nvarchar(1000)
AS
	insert into instructors (istructorname, phone, email)
	values (@istructorname, @phone, @email)
	--get new identity value
	declare @id int = SCOPE_IDENTITY()
	--insert to instructorsubjects
	insert into instructorsubjects(instructorid, subjectid)
	select @id,RTRIM(LTRIM(value)) as value from string_split(@subjecids, ',')
GO
--trigger prevent more than 15 student per batch
create trigger trPreventOverStudent
on students 
after insert
as
begin
	declare @bid int, @count int
	select @bid = batchid from inserted
	select @count = count(*) from students where batchid = @bid
	If @count > 15
	begin
		rollback transaction
		;
		throw 50001, 'Already 15 students enrolled in the batch',  1
	end

end
go
create function getStudentListCSV(@batchid int) returns nvarchar(max)
begin
	DECLARE @x NVARCHAR(2000)
	SET @x= (SELECT  RTRIM(LTRIM(s.studentname)) + ', ' AS 'data()' 
	FROM [batches] b
	INNER JOIN students s ON b.batchid = s.batchid
	WHERE b.batchid = 1
	FOR XML PATH(''))
	
	SET @x= RTRIM(@x)
	SET @x =LEFT(@x, LEN(@x)-1)
	return @x
end
go
create function batchInfo(@batchid int ) returns table
as
return (
	select  b.batchid, b.startdate, dbo.getStudentListCSV(@batchid) as 'students'
	from [batches] b
	where batchid = @batchid
)
go
create function fnPagedStudentList(@batchid int, @page int, @perpage int) returns table
as
return (
	select *
	from students
	where batchid = @batchid
	order by studentid
	offset (@page-1)*@perpage rows
	fetch next @perpage rows only
)
go