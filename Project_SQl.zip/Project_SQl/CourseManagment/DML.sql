use coursedb
go
--initial data
insert into techsubjects values
('HTML5'), ('Website design'),('CSS'), ('Bootstrap'), 
('JavaScript'), ('C#'), ('Angular'), ('React'), ('ASP.NET'), ('MVC'), ('MVC Core')
go


exec spInsertInstructor @istructorname ='Rahmatullah Muzahid',
						@email ='arif@gmail.com',
						@phone='01710xxxxxx',
						@subjecids ='1,2,3,4'
exec spInsertInstructor @istructorname ='Arif Hossain',
						@email ='arif@gmail.com',
						@phone='01710xxxxxx',
						@subjecids ='9, 10, 11'
exec spInsertInstructor @istructorname ='Kamrul Hossain',
						@email ='km@gmail.com',
						@phone='01710xxxxxx',
						@subjecids ='7, 8'
select * from instructors
select * from instructorsubjects
go
insert into courses( title,totalclass, weeklyclass, classduration, fee, instructorid)
values ('MVC Core 3', 30, 3, 4, 30000.00, 1)
go
insert into [batches] (courseid, startdate)
values(1, '2020-10-01')
go
--test 15 over student
declare @i int =1
WHILE @i <= 16
BEGIN
	--at @i =16 it fail for trigger
	insert into students (studentname, phone, batchid)
	values('Student ' + cast(@i as varchar), '017120111' +cast(@i as varchar), 1)
	SET @i = @i +1
END
GO
--check info function
select * from batchInfo(1)
go
--check paged studentlist function
select * from fnPagedStudentList(1, 2, 5)
go
