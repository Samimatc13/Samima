﻿using ProjectTraineeCourse.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjectTraineeCourse
{
    class Program
    {
        static void Main(string[] args)
        {
            IDBGraduate t1 = new IDBGraduate("123456", "Hasan Ahmed", CourseCode.ESAD, "hasan@mail.com", new DateTime(2019, 2, 3), null);
            IDBGraduate t2 = new IDBGraduate("123457", "Kamal Ahmed", CourseCode.J2EE, "kamal@mail.com", new DateTime(2019, 2, 3), new DateTime(2020, 12, 20));
            CourseInfo<IDBGraduate> g = new CourseInfo<IDBGraduate>();
            Console.WriteLine(t1);
            Console.WriteLine("Module studied: ");
            g.ModuleList(t1).ToList().ForEach(m =>
            {
                Console.WriteLine($"{m.ModuleId} Classes {m.NumberOfClass}");
            });
            Console.WriteLine();
            Console.WriteLine(t2);
            Console.WriteLine("Module studied: ");
            g.ModuleList(t2).ToList().ForEach(m =>
            {
                Console.WriteLine($"{m.ModuleId} Classes {m.NumberOfClass}");
            });
            Console.ReadLine();
        }
    }
}
