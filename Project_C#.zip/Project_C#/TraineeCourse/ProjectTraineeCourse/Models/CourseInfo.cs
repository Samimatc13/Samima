﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjectTraineeCourse.Models
{
    public class CourseInfo<T>: ICourseInfo<T> where T:IDBGraduate
    {
        
        
       

        

        public IEnumerable<CourseModule> ModuleList(T trainee)
        {
            List<CourseModule> modules;
            switch (trainee.AssignedCourse)
            {
                case CourseCode.ESAD:
                    modules = ModuleHelper.Modules.Where(m => m.Course == CourseCode.ESAD).ToList();
                    break;
                case CourseCode.NT:
                    modules = ModuleHelper.Modules.Where(m => m.Course == CourseCode.NT).ToList();
                    break;
                case CourseCode.DDD:
                    modules = ModuleHelper.Modules.Where(m => m.Course == CourseCode.DDD).ToList();
                    break;
                case CourseCode.J2EE:
                    modules = ModuleHelper.Modules.Where(m => m.Course == CourseCode.J2EE).ToList();
                    break;
                default:
                    modules = new List<CourseModule>();
                    break;
            }
            return modules;
        }
        
    }
}
