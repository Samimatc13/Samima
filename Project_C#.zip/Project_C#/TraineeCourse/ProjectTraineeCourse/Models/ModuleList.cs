﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjectTraineeCourse.Models
{
    
    public static class ModuleHelper
    {
        public static List<CourseModule> Modules
        {
            get
            {
                return new List<CourseModule>
                {
                    new CourseModule{ ModuleId=1, ModuleName="SQL Server 2016", NumberOfClass=25, Course=CourseCode.ESAD},
                    new CourseModule{ ModuleId=2, ModuleName="SProgramming C#", NumberOfClass=30, Course=CourseCode.ESAD},
                    new CourseModule{ ModuleId=3, ModuleName="OOSAD using UML", NumberOfClass=20, Course=CourseCode.ESAD},
                    new CourseModule{ ModuleId=4, ModuleName="HTML5 & CSS3", NumberOfClass=25, Course=CourseCode.ESAD},
                    new CourseModule{ ModuleId=5, ModuleName="Widows 10", NumberOfClass=25, Course=CourseCode.NT},
                    new CourseModule{ ModuleId=6, ModuleName="RedHat Linux", NumberOfClass=30, Course=CourseCode.NT},
                    new CourseModule{ ModuleId=7, ModuleName="Exchange Server", NumberOfClass=20, Course=CourseCode.NT},
                    new CourseModule{ ModuleId=8, ModuleName="Azzure Admin", NumberOfClass=25, Course=CourseCode.NT},
                     new CourseModule{ ModuleId=9, ModuleName="PL/QL", NumberOfClass=30, Course=CourseCode.DDD},
                    new CourseModule{ ModuleId=10, ModuleName="Oracle", NumberOfClass=20, Course=CourseCode.DDD},
                    new CourseModule{ ModuleId=11, ModuleName="Developer", NumberOfClass=25, Course=CourseCode.DDD},
                     new CourseModule{ ModuleId=12, ModuleName="Java Programming", NumberOfClass=30, Course=CourseCode.J2EE},
                    new CourseModule{ ModuleId=13, ModuleName="MySQL", NumberOfClass=20, Course=CourseCode.J2EE},
                    new CourseModule{ ModuleId=14, ModuleName="Android", NumberOfClass=25, Course=CourseCode.J2EE}

                };
            }
        }
    }
}
