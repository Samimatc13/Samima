﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjectTraineeCourse.Models
{
    public interface ICourseInfo<T> 
    {
        IEnumerable<CourseModule> ModuleList(T trainee);
    }
}
