﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjectTraineeCourse.Models
{
    public enum CourseCode { ESAD,NT,DDD,J2EE}
    public abstract class IDBTrainee
    {
        public IDBTrainee() { }
        public IDBTrainee(string id, string fullName, CourseCode course, string  email) {
            this.Id = id; this.FullName = fullName; this.AssignedCourse = course; this.Email = email; 
        }
        public string Id { get; set; }
        public string FullName { get; set; }
        public CourseCode AssignedCourse { get; set; }
        public string Email { get; set; }
        
        
    }
}
