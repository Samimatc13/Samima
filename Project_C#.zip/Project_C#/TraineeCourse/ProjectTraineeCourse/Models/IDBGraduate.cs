﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjectTraineeCourse.Models
{
    public class IDBGraduate:IDBTrainee
    {
        public IDBGraduate() { }
        public IDBGraduate(string id, string fullName, CourseCode course, string email, DateTime startDate, DateTime? completeDate)
            :base(id, fullName, course, email)
        {
            this.DateStarted = startDate; this.DateCompleted = completeDate;
        }
        public DateTime DateStarted { get; set; }
        public DateTime? DateCompleted { get; set; }
        public override string ToString()
        {
            return $"{FullName} holding id-{Id} in course {AssignedCourse}, started on {DateStarted:yyyy-MMM-dd} " +
                $"{(DateCompleted.HasValue ? DateCompleted.Value.ToString("yyyy-MMM-ddd") : "continuing")}\r\n" +
                $"Email: {Email}";
        }
    }
}
