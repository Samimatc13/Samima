﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjectListQuery.Models
{
    public enum Course
    {
        ESAD, NT, DDD, J2EE
    }
}
