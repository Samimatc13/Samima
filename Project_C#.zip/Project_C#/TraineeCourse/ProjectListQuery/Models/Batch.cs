﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjectListQuery.Models
{
    public class Batch
    {
        public int BatchId { get; set; }
        public string BatchCode { get; set; }
        public Course Course { get; set; }
    }
}
