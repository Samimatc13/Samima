﻿using ProjectListQuery.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjectListQuery
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Batch> batches = new List<Batch>
            {
                new Batch{ BatchId=1, BatchCode="CS/ACSL-A/42/01", Course=Course.ESAD},
                new Batch{ BatchId=2, BatchCode="CS/ACSL-M/42/01", Course=Course.ESAD},
                new Batch{ BatchId=3, BatchCode="DDD/ACSL-A/43/01", Course=Course.DDD},
                new Batch{ BatchId=4, BatchCode="NT/ACSL-M/44/01", Course=Course.NT},
                
            };
            List<Trainee> trainees = new List<Trainee>
            {
                new Trainee{  TraineeId=1, Name="Kamrul Islam",Phone="01910121212", BirthDate=new DateTime(2009, 07, 3), BatchId=1},
                new Trainee{  TraineeId=2, Name="Rustom Ali",Phone="01710121212", BirthDate=new DateTime(2009, 5, 13), BatchId=1},
                new Trainee{  TraineeId=3, Name="Meherunnesa",Phone="01810121212", BirthDate=new DateTime(2008, 07, 3), BatchId=1},
                new Trainee{  TraineeId=4, Name="Reyad Ahmed",Phone="01610121212", BirthDate=new DateTime(2009, 07, 3), BatchId=1},
                new Trainee{  TraineeId=5, Name="Nazmul Islam",Phone="01310121212", BirthDate=new DateTime(2008, 2, 11), BatchId=1},
                new Trainee{  TraineeId=6, Name="Mizaul Islam",Phone="01990121212", BirthDate=new DateTime(2009, 07, 3), BatchId=3},
                new Trainee{  TraineeId=7, Name="Abid Rahman",Phone="01670121212", BirthDate=new DateTime(2009, 07, 3), BatchId=3},
                new Trainee{  TraineeId=8, Name="Fajana Shompa",Phone="01780121212", BirthDate=new DateTime(2009, 07, 3), BatchId=3},
                new Trainee{  TraineeId=9, Name="Abdur Rashid",Phone="01790121212", BirthDate=new DateTime(2009, 07, 3), BatchId=4},
                new Trainee{  TraineeId=10, Name="Akter Ahmed",Phone="01711121212", BirthDate=new DateTime(2008, 4, 23), BatchId=4},
                new Trainee{  TraineeId=11, Name="Sumon Robin",Phone="01712121212", BirthDate=new DateTime(2009, 07, 3), BatchId=4}
            };
            Console.WriteLine("Batch and Trainees\n");
            batches.ForEach(b =>
            {
                Console.WriteLine($"{b.BatchCode}\t{b.Course}\n");
                trainees
                .Where(t => t.BatchId == b.BatchId)
                .ToList()
                .ForEach(tr =>
                {
                    Console.WriteLine($"\t{tr.Name}\t{tr.Phone}\t{tr.BirthDate:yyyy-MM-dd}");
                });
                Console.WriteLine();
            });
            
            Console.WriteLine();
            Console.WriteLine("Query Results:");
            Console.WriteLine("===========================");
            Console.WriteLine("Using query syntax:\n");

            Console.WriteLine("Trainee List sorted on Birt Date (DESCENDING):\n");
            
            var q1 = from t in trainees
                    orderby t.BirthDate descending
                    select new {
                        t.Name,
                        t.BirthDate,
                        t.Phone,
                        Batch= (from b in batches
                                where b.BatchId == t.BatchId
                                select b.BatchCode).FirstOrDefault()
                    };
           foreach(var r in q1)
            {
                Console.WriteLine($"\t{r.Name}\t{r.Phone}\t{r.BirthDate:yyyy-MM-dd}\t{r.Batch}");
            }
            Console.WriteLine();
            Console.WriteLine("Filtering: Born in 2009:\n");
            trainees
                    .Where(t => t.BirthDate.Year == 2009)
                    .ToList()
                    .ForEach(r =>
                    {
                        Console.WriteLine($"\t{r.Name}\t{r.Phone}\t{r.BirthDate:yyyy-MM-dd}");
                    });
            Console.WriteLine();
            Console.WriteLine("Join: inner join:\n");
            var q3 = batches.Join(trainees,
                b => b.BatchId,
                t => t.BatchId,
                (b, t)=> new { b.BatchCode, b.Course, t.TraineeId, t.Name});
            foreach (var r in q3)
            {
                Console.WriteLine($"\t{r.BatchCode.PadRight(20, ' ')}\t{r.Course.ToString().PadRight(5, ' ')}\t{r.TraineeId}\t{r.Name}");
            }
            Console.WriteLine();
            Console.WriteLine("Join: left outer join:\n");
            var q4 = from b in batches
                     join t in trainees on b.BatchId equals t.BatchId into tb
                     from t in tb.DefaultIfEmpty()
                     select new {BatchCode = b.BatchCode, b.Course, t?.TraineeId, t?.Name };
            foreach (var r in q4)
            {
                Console.WriteLine($"\t{r.BatchCode.PadRight(20,' ')}\t{r.Course.ToString().PadRight(5,' ')}\t{r.TraineeId}\t{r.Name}");
            }
            Console.ReadLine();
        }
    }
}
